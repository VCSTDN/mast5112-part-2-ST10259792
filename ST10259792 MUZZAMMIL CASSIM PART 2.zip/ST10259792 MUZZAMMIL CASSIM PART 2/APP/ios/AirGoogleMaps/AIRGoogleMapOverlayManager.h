//
//  AIRGoogleMapOverlayManager.h
//  Created by Taro Matsuzawa on 3/5/17.
//

#import <Foundation/Foundation.h>
#import <React/RCTViewManager.h>

@interface AIRGoogleMapOverlayManager : RCTViewManager
@end
