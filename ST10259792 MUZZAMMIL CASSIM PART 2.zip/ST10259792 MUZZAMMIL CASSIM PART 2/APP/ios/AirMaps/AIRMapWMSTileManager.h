//
//  AIRMapWMSTileManager.h
//  AirMaps
//
//  Created by nizam on 10/28/18.
//  Copyright © 2018. All rights reserved.
//


#import <React/RCTViewManager.h>

@interface AIRMapWMSTileManager : RCTViewManager

@end
