package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Book1Page2 extends AppCompatActivity {

    Button btn1;
    Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book1_page2);
        btn1 = findViewById(R.id.Book1Page2Home);
        btn2 = findViewById(R.id.Done1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities1();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities2();
            }
        });


    }

    private void switchActivities1() {
        Intent switchActivityIntent = new Intent(this, Act3Home.class);
        startActivity(switchActivityIntent);
    }
    private void switchActivities2() {
        Intent switchActivityIntent = new Intent(this,Act3Home.class);
        startActivity(switchActivityIntent);
    }

}
