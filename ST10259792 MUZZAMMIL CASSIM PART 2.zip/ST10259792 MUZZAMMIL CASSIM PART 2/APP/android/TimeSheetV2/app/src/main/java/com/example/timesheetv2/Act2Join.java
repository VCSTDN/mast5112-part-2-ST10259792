package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Act2Join extends AppCompatActivity {
EditText ed1;
Button G2H;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act2_join);


        G2H = findViewById(R.id.GoToHomeButton);
        G2H.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities();
            }
        });


    }

    private void switchActivities() {
        Intent switchActivityIntent = new Intent(this, Act3Home.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivitiesWithData() {
        Intent switchActivityIntent = new Intent(this, Act3Home.class);
        switchActivityIntent.putExtra("message", "From: " + Act2Join.class.getSimpleName());
        startActivity(switchActivityIntent);
    }
}
