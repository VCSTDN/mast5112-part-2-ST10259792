package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button switchToSecondActivity;
    Button btnstart;
    Button S2Home1;
    Button S2Home2;
    Button S2Home3;
    Button S2Home4;
    Button Search1;
    Button Search2;
    Button Search3;
    Button Search4;
    Button Filter1;
    Button Filter2;
    Button Filter3;
    Button Filter4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act1_start);



        btnstart = findViewById(R.id.start);
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities();
            }
        });


    }

    private void switchActivities() {
        Intent switchActivityIntent = new Intent(this, Act2Join.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivitiesWithData() {
        Intent switchActivityIntent = new Intent(this, Act2Join.class);
        switchActivityIntent.putExtra("message", "From: " + MainActivity.class.getSimpleName());
        startActivity(switchActivityIntent);
    }
}
