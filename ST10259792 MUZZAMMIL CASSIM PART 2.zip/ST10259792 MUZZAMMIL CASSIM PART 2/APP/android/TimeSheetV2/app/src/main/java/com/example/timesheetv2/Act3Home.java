package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Act3Home extends AppCompatActivity {

    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act3_home);
        btn1 = findViewById(R.id.btnContinueReading);
        btn2 = findViewById(R.id.btnStartNew);

        btn3 = findViewById(R.id.btnSearch);

        btn4 = findViewById(R.id.btnCollection);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities1();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities2();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities3();
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities4();
            }
        });


    }

    private void switchActivities1() {
        Intent switchActivityIntent = new Intent(this, Book1Page2.class);
        startActivity(switchActivityIntent);
    }
    private void switchActivities2() {
        Intent switchActivityIntent = new Intent(this, NewBooks.class);
        startActivity(switchActivityIntent);
    }
    private void switchActivities3() {
        Intent switchActivityIntent = new Intent(this, SearchPage.class);
        startActivity(switchActivityIntent);
    }
    private void switchActivities4() {
        Intent switchActivityIntent = new Intent(this, Collection.class);
        startActivity(switchActivityIntent);
    }


}
