package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Collection extends AppCompatActivity {
Button btn1;
    Button btn2;
    Button btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);
        btn1 = findViewById(R.id.CollectionHome);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities1();
            }
        });

        btn1 = findViewById(R.id.OpenBook1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities2();
            }
        });

        btn1 = findViewById(R.id.OpenBook2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities3();
            }
        });


    }

    private void switchActivities1() {
        Intent switchActivityIntent = new Intent(this, Act3Home.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities2() {
        Intent switchActivityIntent = new Intent(this, Book1Page1.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities3() {
        Intent switchActivityIntent = new Intent(this, Book2Page1.class);
        startActivity(switchActivityIntent);
    }


}
