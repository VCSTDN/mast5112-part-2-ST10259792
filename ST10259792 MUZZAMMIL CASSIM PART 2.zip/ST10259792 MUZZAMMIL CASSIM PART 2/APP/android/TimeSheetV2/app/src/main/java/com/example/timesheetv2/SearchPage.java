package com.example.timesheetv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SearchPage extends AppCompatActivity {

    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);

        btn1 = findViewById(R.id.HomeSearch);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities1();
            }
        });


        btn2 = findViewById(R.id.Search1);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities2();
            }
        });

        btn3 = findViewById(R.id.Search2);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities3();
            }
        });

        btn4 = findViewById(R.id.Search3);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities4();
            }
        });

        btn5 = findViewById(R.id.Search4);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities5();
            }
        });


    }

    private void switchActivities1() {
        Intent switchActivityIntent = new Intent(this, Act3Home.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities2() {
        Intent switchActivityIntent = new Intent(this, Book1NameCover.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities3() {
        Intent switchActivityIntent = new Intent(this, Book2NameCover.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities4() {
        Intent switchActivityIntent = new Intent(this, Book1AuthorCover.class);
        startActivity(switchActivityIntent);
    }

    private void switchActivities5() {
        Intent switchActivityIntent = new Intent(this, Book2AuthorCover.class);
        startActivity(switchActivityIntent);
    }


}
